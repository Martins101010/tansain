<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/vnd.microsoft.icon" />

    <title>E-Portal | Tansian University</title>

    <link rel='stylesheet' href='plugins/goodlayers-core/plugins/combine/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/goodlayers-core/include/css/page-builder.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/revslider/public/assets/css/settings.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/style-core.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/kingster-style-custom.css' type='text/css' media='all' />

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700%2C400" rel="stylesheet" property="stylesheet" type="text/css" media="all">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CABeeZee%3Aregular%2Citalic&amp;subset=latin%2Clatin-ext%2Cdevanagari&amp;ver=5.0.3' type='text/css' media='all' />

</head>

<body class="home page-template-default page page-id-2039 gdlr-core-body woocommerce-no-js tribe-no-js kingster-body kingster-body-front kingster-full  kingster-with-sticky-navigation  kingster-blockquote-style-1 gdlr-core-link-to-lightbox">
    <div class="kingster-mobile-header-wrap">
        <div class="kingster-mobile-header kingster-header-background kingster-style-slide kingster-sticky-mobile-navigation " id="kingster-mobile-header">
            <div class="kingster-mobile-header-container kingster-container clearfix">
                <div class="kingster-logo  kingster-item-pdlr">
                    <div class="kingster-logo-inner">
                        <a class="" href='/'><img src="images/logo.png" alt="Home" title="Home" /></a>
                    </div>
                </div>
                <div class="kingster-mobile-menu-right">
                    
                    
                    <div class="kingster-mobile-menu"><a class="kingster-mm-menu-button kingster-mobile-menu-button kingster-mobile-button-hamburger" href="#kingster-mobile-menu"><span></span></a>
                        <div class="kingster-mm-menu-wrap kingster-navigation-font" id="kingster-mobile-menu" data-slide="right">
                            <ul id="menu-main-navigation" class="m-menu">
                                <li class="menu-item"><a href='/'>Home</a></li>
                                <li class="menu-item"><a href="about.php">About</a></li>
                                <li class="menu-item"><a href="courses.php">Courses</a></li>
                                <li class="menu-item"><a href="campus-tour.php">Campus Tour</a></li>
                                <li class="menu-item"><a href="fees.php">Fees</a></li>
                                <li class="menu-item"><a href="admissions.php">Admissions</a></li>
                                <li class="menu-item"><a href="contact.php">Contact</a></li>
                                <li class="menu-item"><a href="eportal.php">E-Portal</a></li>
                                <li class="menu-item menu-item-has-children"><a href="#">Transcript</a>
                                    <ul class="sub-menu">
                                        <strong>For Transcript, send an email to registar@tansianuniversity.edu.ng</strong>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    <div class="kingster-body-outer-wrapper ">
        <div class="kingster-body-wrapper clearfix  kingster-with-frame">

            <link rel='stylesheet' href='./popup/popup.css' type='text/css' media='all' />
<script type='text/javascript' src='./popup/popup.js'></script>

 <div class="kingster-top-bar">
                <div class="kingster-top-bar-background"></div>
                <div class="kingster-top-bar-container kingster-container ">
                    <div class="kingster-top-bar-container-inner clearfix">
                        <div class="kingster-top-bar-left kingster-item-pdlr"><i class="fa fa-envelope-open-o" id="i_fd84_0"></i> enquiry@tansianuniversity.edu.ng <i class="fa fa-phone" id="i_fd84_1"></i> <a id="a_1dd7_8" href="tel:+2348039310930">+234 (0) 803 931 0930</a> </div>
                        <div class="kingster-top-bar-right kingster-item-pdlr">
                            <ul id="kingster-top-bar-menu" class="sf-menu kingster-top-bar-menu kingster-top-bar-right-menu">
                                <li class="menu-item kingster-normal-menu"><a href="eportal.php">E-Portal</a></li>
                                <li class="menu-item kingster-normal-menu"><a href="#"><div class="popup" onclick="myFunction()">Transcript<span class="popuptext" id="myPopup">For Transcript, send an email to registar@tansianuniversity.edu.ng</span></div></a></li>
                                <li class="menu-item kingster-normal-menu"><a href="#">E-Library</a></li>
                            </ul>
                            <div class="kingster-top-bar-right-social"></div><a class="kingster-top-bar-right-button" href="admissions.php#online-application">Discover Tansian</a></div>
                    </div>
                </div>
            </div>            
            <header class="kingster-header-wrap kingster-header-style-plain  kingster-style-menu-right kingster-sticky-navigation kingster-style-fixed" data-navigation-offset="75px">
                <div class="kingster-header-background"></div>
                <div class="kingster-header-container  kingster-container">
                    <div class="kingster-header-container-inner clearfix">
                        <div class="kingster-logo  kingster-item-pdlr">
                            <div class="kingster-logo-inner">
                                <a class="" href='/'><img src="images/logo.png" alt="Home" title="Home" /></a>
                            </div>
                        </div>
                        <div class="kingster-navigation kingster-item-pdlr clearfix ">
                            <div class="kingster-main-menu" id="kingster-main-menu">
                                <ul id="menu-main-navigation-1" class="sf-menu">
                                    <li class="menu-item kingster-normal-menu"><a href='/'>Home</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="about.php">About</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="courses.php">Courses</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="campus-tour.php">Campus Tour</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="fees.php">Fees</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="admissions.php">Admissions</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="contact.php">Contact</a></li>
                                </ul>
                                <div class="kingster-navigation-slide-bar" id="kingster-navigation-slide-bar"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>



            <div class="kingster-page-title-wrap  kingster-style-medium kingster-left-align">
                <div class="kingster-header-transparent-substitute"></div>
                <div class="kingster-page-title-overlay"></div>
                <div class="kingster-page-title-container kingster-container">
                    <div class="kingster-page-title-content kingster-item-pdlr">
                        <h1 class="kingster-page-title">Tansian University E-Portal</h1></div>
                </div>
            </div>
            
            
            <div class="kingster-content-container kingster-container">
                    <div class=" kingster-sidebar-wrap clearfix kingster-line-height-0 kingster-sidebar-style-none">
                        <div class=" kingster-sidebar-center kingster-column-60 kingster-line-height">
                            <div class="kingster-content-wrap kingster-item-pdlr clearfix">
                                <div class="kingster-content-area">
                                    <article id="post-1268" class="post-1268 post type-post status-publish format-standard has-post-thumbnail hentry category-blog category-post-format tag-news">
                                        <div class="kingster-single-article clearfix">
                                            <div class="kingster-single-article-content">
                                                <p>
                                                    <h3 align="center"><strong>HOW TO USE</strong></h3>

<ul>
    <li>Click on the <strong>Login</strong> Button below to take you to the E-Portal or type in your browser, <strong>https://eportal.tansianuniversity.edu.ng/</strong> to visit same.</li>
    <li>Click on the <strong>Sign Up</strong> link and fill the required information correctly, you will be redirected to the Login Page when are done. (This step is for <strong>NEW STUDENTS ONLY</strong>. Returning Students should proceed to next step)</li>
    <li>On the Login Page, Select <strong>I am a student</strong>, log in to the E-Portal using your registered <strong>Reg. Number</strong> and <strong>password</strong>.</li>
    <li>When logged on, for Desktop Computer View, locate the side menu and the <strong>Course Registration</strong> collapsible menu item.  For Mobile View, expand the side menu to view (button is located at the top-left beside the School Logo)</li>
    <li>For <strong>Regular</strong>, courses are loaded automatically. Scroll down and locate the <strong>COURSE REGISTRATION PIN Input Box</strong>. Input your <strong>PIN </strong>on the <strong>Scratch Card</strong> and <strong>Register</strong> your courses.</li>
    <li>For <strong>Summer</strong>, select the course(s) you want to register. Scroll down and locate the <strong>COURSE REGISTRATION PIN Input Box</strong>. Input your <strong>PIN</strong> on the <strong>Scratch Card</strong> and <strong>Register</strong> your courses.</li>
    <li>After the course registration, click on the <strong>Print</strong> button and proceed with the printing of your course form.</li>
    <li>Explore and view other menu items.</li>
    <li>You can Edit your profile, Change your password and Logout using the <strong>User</strong> button located at the top-right of your page.</li>
</ul>

<p align="center"><strong>PLEASE NOTE: You can only use a PIN once and you can view the <strong>Results</strong> for <strong>ONLY</strong> the course(s) you registered.</strong></p>

<div class="gdlr-core-button-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-center-align"><a class="gdlr-core-button  gdlr-core-button-solid gdlr-core-button-no-border" href="https://eportal.tansianuniversity.edu.ng/" target="_blank" id="a_1dd7_0"><span class="gdlr-core-content" >LOGIN</span></a></div>


<p align="center"><strong>For E-Portal Technical Support, kindly visit the ICT Center or send an email to <span style="color:green">eportalsupport@tansianuniversity.edu.ng</span></strong></p>
                                                </p>
                                                
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            <footer>
                <div class="kingster-footer-wrapper ">
                    <div class="kingster-footer-container kingster-container clearfix">
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="text-2" class="widget widget_text kingster-widget">
                                <div class="textwidget">
                                    <p><img src="upload/footer-logo.png" alt="" />
                                        <br /> <span class="gdlr-core-space-shortcode" id="span_1dd7_10"></span>
                                        <br /> P.M.B 0006,
                                        <br /> Along Enugu - Onitsha Expressway,
                                        <br /> Umunya, 
                                        <br />Anambra State, Nigeria</p>
                                    <p><span id="span_1dd7_11"><a id="a_1dd7_8" href="tel:+2348039310930">+234 (0) 803 931 0930</a></span>
                                        <br /> <span class="gdlr-core-space-shortcode" id="span_1dd7_12"></span>
                                        <br /> <a id="a_1dd7_8" href="mailto:enquiry@tansianuniversity.edu.ng">enquiry@tansianuniversity.edu.ng</a></p>
                                    <div class="gdlr-core-divider-item gdlr-core-divider-item-normal gdlr-core-left-align">
                                        <div class="gdlr-core-divider-line gdlr-core-skin-divider" id="div_1dd7_111"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-2" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">The Team</h3><span class="clear"></span>
                                <div class="menu-our-campus-container">
                                    <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="chancellor.php">The Chancellor</a></li>
                                        <li class="menu-item"><a href="pro-chancellor.php">The Pro-Chancellor</a></li>
                                        <li class="menu-item"><a href="vice-chancellor.php">The Vice Chancellor</a></li>
                                        <li class="menu-item"><a href="deputy-vice-chancellor.php">The Deputy Vice Chancellor</a></li>
                                        <li class="menu-item"><a href="registrar.php">The Registrar</a></li>
                                        <li class="menu-item"><a href="bursar.php">The Bursar</a></li>
										<li class="menu-item"><a href="founder.php"><strong>THE FOUNDER</strong></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-3" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">Quick Links</h3><span class="clear"></span>
                                <div class="menu-campus-life-container">
                                    <ul id="menu-campus-life" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="calendar.php">Tansian University Year Calendar</a></li>
                                        <li class="menu-item"><a href="radio.php">Tansian University Radio</a></li>
                                        <li class="menu-item"><a href="films.php">Tansian University Films</a></li>
                                        <li class="menu-item"><a href="sports.php">Tansian University Sports Academy</a></li>
                                        <li class="menu-item"><a href="health-clinic.php">Tansian University Health Clinic</a></li>
                                        <li class="menu-item"><a href="alumni.php">Tansian University Alumni</a></li>
                                        <li class="menu-item"><a href="https://webmail.tansianuniversity.edu.ng/" target="_blank">Staff Mail</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-4" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">University Anthem (Lyrics)</h3><span class="clear"></span>
                                <div style="overflow: auto; height:235px">
                                    <p><em>Tansian University (2x)</em></p>

                                    <p><em>Home of active learning and high quality education</em></p>
                                    
                                    <p><em>Knowledge is power, knowledge is virtue<br />
                                    Scientia Potestas et Virtus (2x)</em></p>

                                    <p><em>Tansian University (2x)</em></p>

                                    <p><em>A citadel of learning to immortalize Blessed Iwene Tansian<br />
                                    A citadel of good living for all peoples without distinction<br />
                                    A citadel where Christ is the centre for ages and ages to come<br />
                                    So may we pray God to lead us on<br />
                                    In this life and in the life to come</em></p>
                                    <p><em>Iwene</em></p>

                                    <p><em>Tansian University (2x)</em></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="kingster-copyright-wrapper">
                    <div class="kingster-copyright-container kingster-container clearfix">
                        <div class="kingster-copyright-left kingster-item-pdlr">Copyright &copy; 2022, Tansian University</a>. All Rights Reserved. | <small>Website by <a href="http://www.codecmultimedia.com/" target="_blank" title="CODEC Multimedia Services">CODEC Multimedia Services</a></small></div>
                        <div class="kingster-copyright-right kingster-item-pdlr">
                            <div class="gdlr-core-social-network-item gdlr-core-item-pdb  gdlr-core-none-align" id="div_1dd7_112">
                                <a href="https://www.facebook.com/tansianuniversityumunya/" target="_blank" class="gdlr-core-social-network-icon" title="facebook">
                                    <i class="fa fa-facebook" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="google-plus">
                                    <i class="fa fa-google-plus" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="linkedin">
                                    <i class="fa fa-linkedin" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="skype">
                                    <i class="fa fa-skype" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="twitter">
                                    <i class="fa fa-twitter" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="instagram">
                                    <i class="fa fa-instagram" ></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>


	<script type='text/javascript' src='js/jquery/jquery.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='plugins/goodlayers-core/plugins/combine/script.js'></script>
    <script type='text/javascript'>
        var gdlr_core_pbf = {
            "admin": "",
            "video": {
                "width": "640",
                "height": "360"
            },
            "ajax_url": "#"
        };
    </script>
    <script type='text/javascript' src='plugins/goodlayers-core/include/js/page-builder.js'></script>
    <script type='text/javascript' src='js/jquery/ui/effect.min.js'></script>
    <script type='text/javascript'>
        var kingster_script_core = {
            "home_url": "index.php"
        };
    </script>
    <script type='text/javascript' src='js/plugins.min.js'></script>
</body>
</html>