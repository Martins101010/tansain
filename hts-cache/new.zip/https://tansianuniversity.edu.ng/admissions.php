

<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/vnd.microsoft.icon" />

    <title>Admissions | Tansian University</title>
    
    <meta name="keywords" content="best education in nigeria, best university in nigeria, lowest paying university in nigeria, affordable university in nigeria, tansian university umunya, tansian university oba, low cost university in nigeria, nuc accredited university, schools in anambra state, schools in nigeria" />
    <meta name="description" content="Applications are hereby invited from suitably qualified candidates for admissions into Tansian University. Tansian University is the best private university in Nigeria. In Tansian University, We Breed New Ideas, Fresh Solutions and New Perspectives hence Making A Difference is Our Major Philosophy.">
    <meta name="author" content="CODEC Multimedia Services">

    <!-- OG Meta Tags -->
    <meta property="og:site_name" content="Tansian University" />
    <meta property="og:title" content="Tansian University | The Citadel of Learning">
    <meta property="og:description" content="Applications are hereby invited from suitably qualified candidates for admissions into Tansian University. Tansian University is the best private university in Nigeria. In Tansian University, We Breed New Ideas, Fresh Solutions and New Perspectives hence Making A Difference is Our Major Philosophy.">
    <meta property="og:image" content="http://tansianuniversity.edu.ng/upload/logo-white.png">
    <meta property="og:url" content="https://tansianuniversity.edu.ng/">
    <meta property="og:type" content="website" />

    <link rel='stylesheet' href='plugins/goodlayers-core/plugins/combine/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/goodlayers-core/include/css/page-builder.css' type='text/css' media='all' />
    <link rel='stylesheet' href='plugins/revslider/public/assets/css/settings.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/style-core.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/kingster-style-custom.css' type='text/css' media='all' />

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700%2C400" rel="stylesheet" property="stylesheet" type="text/css" media="all">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CABeeZee%3Aregular%2Citalic&amp;subset=latin%2Clatin-ext%2Cdevanagari&amp;ver=5.0.3' type='text/css' media='all' />

</head>

<body class="home page-template-default page page-id-2039 gdlr-core-body woocommerce-no-js tribe-no-js kingster-body kingster-body-front kingster-full  kingster-with-sticky-navigation  kingster-blockquote-style-1 gdlr-core-link-to-lightbox">

    <div class="kingster-mobile-header-wrap">
        <div class="kingster-mobile-header kingster-header-background kingster-style-slide kingster-sticky-mobile-navigation " id="kingster-mobile-header">
            <div class="kingster-mobile-header-container kingster-container clearfix">
                <div class="kingster-logo  kingster-item-pdlr">
                    <div class="kingster-logo-inner">
                        <a class="" href='/'><img src="images/logo.png" alt="Home" title="Home" /></a>
                    </div>
                </div>
                <div class="kingster-mobile-menu-right">
                    
                    
                    <div class="kingster-mobile-menu"><a class="kingster-mm-menu-button kingster-mobile-menu-button kingster-mobile-button-hamburger" href="#kingster-mobile-menu"><span></span></a>
                        <div class="kingster-mm-menu-wrap kingster-navigation-font" id="kingster-mobile-menu" data-slide="right">
                            <ul id="menu-main-navigation" class="m-menu">
                                <li class="menu-item"><a href='/'>Home</a></li>
                                <li class="menu-item"><a href="about.php">About</a></li>
                                <li class="menu-item"><a href="courses.php">Courses</a></li>
                                <li class="menu-item"><a href="campus-tour.php">Campus Tour</a></li>
                                <li class="menu-item"><a href="fees.php">Fees</a></li>
                                <li class="menu-item"><a href="admissions.php">Admissions</a></li>
                                <li class="menu-item"><a href="contact.php">Contact</a></li>
                                <li class="menu-item"><a href="eportal.php">E-Portal</a></li>
                                <li class="menu-item menu-item-has-children"><a href="#">Transcript</a>
                                    <ul class="sub-menu">
                                        <strong>For Transcript, send an email to registar@tansianuniversity.edu.ng</strong>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="kingster-body-outer-wrapper ">
        <div class="kingster-body-wrapper clearfix  kingster-with-frame">

            <link rel='stylesheet' href='./popup/popup.css' type='text/css' media='all' />
<script type='text/javascript' src='./popup/popup.js'></script>

 <div class="kingster-top-bar">
                <div class="kingster-top-bar-background"></div>
                <div class="kingster-top-bar-container kingster-container ">
                    <div class="kingster-top-bar-container-inner clearfix">
                        <div class="kingster-top-bar-left kingster-item-pdlr"><i class="fa fa-envelope-open-o" id="i_fd84_0"></i> enquiry@tansianuniversity.edu.ng <i class="fa fa-phone" id="i_fd84_1"></i> <a id="a_1dd7_8" href="tel:+2348039310930">+234 (0) 803 931 0930</a> </div>
                        <div class="kingster-top-bar-right kingster-item-pdlr">
                            <ul id="kingster-top-bar-menu" class="sf-menu kingster-top-bar-menu kingster-top-bar-right-menu">
                                <li class="menu-item kingster-normal-menu"><a href="eportal.php">E-Portal</a></li>
                                <li class="menu-item kingster-normal-menu"><a href="#"><div class="popup" onclick="myFunction()">Transcript<span class="popuptext" id="myPopup">For Transcript, send an email to registar@tansianuniversity.edu.ng</span></div></a></li>
                                <li class="menu-item kingster-normal-menu"><a href="#">E-Library</a></li>
                            </ul>
                            <div class="kingster-top-bar-right-social"></div><a class="kingster-top-bar-right-button" href="admissions.php#online-application">Discover Tansian</a></div>
                    </div>
                </div>
            </div>            <header class="kingster-header-wrap kingster-header-style-plain  kingster-style-menu-right kingster-sticky-navigation kingster-style-fixed" data-navigation-offset="75px">
                <div class="kingster-header-background"></div>
                <div class="kingster-header-container  kingster-container">
                    <div class="kingster-header-container-inner clearfix">
                        <div class="kingster-logo  kingster-item-pdlr">
                            <div class="kingster-logo-inner">
                                <a class="" href='/'><img src="images/logo.png" alt="Home" title="Home" /></a>
                            </div>
                        </div>
                        <div class="kingster-navigation kingster-item-pdlr clearfix ">
                            <div class="kingster-main-menu" id="kingster-main-menu">
                                <ul id="menu-main-navigation-1" class="sf-menu">
                                    <li class="menu-item kingster-normal-menu"><a href='/'>Home</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="about.php">About</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="courses.php">Courses</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="campus-tour.php">Campus Tour</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="fees.php">Fees</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="admissions.php">Admissions</a></li>
                                    <li class="menu-item kingster-normal-menu"><a href="contact.php">Contact</a></li>
                                </ul>
                                <div class="kingster-navigation-slide-bar" id="kingster-navigation-slide-bar"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>


            <div class="kingster-page-title-wrap  kingster-style-custom kingster-left-align" style="background-image: url(upload/page-title-apply.jpg) ;">
                <div class="kingster-header-transparent-substitute"></div>
                <div class="kingster-page-title-overlay"></div>
                <div class="kingster-page-title-bottom-gradient"></div>
                <div class="kingster-page-title-container kingster-container">
                    <div class="kingster-page-title-content kingster-item-pdlr" style="padding-top: 505px ;padding-bottom: 60px ;">
                        <div class="kingster-page-caption" style="font-size: 21px ;font-weight: 400 ;letter-spacing: 0px ;">Admissions</div>
                        <h1 class="kingster-page-title" style="font-size: 48px ;font-weight: 700 ;text-transform: none ;letter-spacing: 0px ;color: #ffffff ;">Apply To Tansian University</h1></div>
                </div>
            </div>
            
            <div class="kingster-page-wrapper" id="kingster-page-wrapper">
                <div class="gdlr-core-page-builder-body">
                    <div class="gdlr-core-pbf-wrapper " style="padding: 40px 0px 30px 0px;">
                        <div class="gdlr-core-pbf-background-wrap"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr">
                                        <div class="gdlr-core-title-item-title-wrap clearfix">
                                            <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 27px ;font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;">Admissions Requirements</h3></div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 17px ;text-transform: none ;">
                                                        <p>Applications are hereby invited from suitably qualified candidates for admissions into the 2021/2022 Academic Session in the undergraduate programmes of Tansian University.
</p>
<p>All candidates applying for admission into any of the undergraduate programmes must:</strong></strong></p>
<ul>
    <li>Possess the academic qualifications as specified by the Joint Admissions and Matriculations Board for Course of choice.</li></ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 17px ;text-transform: none ;">

<ul>
    <li>Achieve at least the approved minimum pass mark in the Unified Tertiary Matriculation Examinations.</li>
</ul>

<p><strong>Note</strong>: Candidate who sat for the 2021 UTME who did not indicate Tansian University in any of their choices are eligible to apply.</p>
<p>There is Direct Entry Admission for NCE holders for two/three Year Degree Programmes in the Faculty of Education.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding: 80px 0px 40px 0px;" data-skin="Column Service">
                        <div class="gdlr-core-pbf-background-wrap" style="background-color: #1b2945 ;"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-15 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-top gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 30px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-media-image" style="margin-bottom: 35px;"><img src="upload/col-icon-1.png" alt="" width="41" height="41" title="col-icon-1" /></div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 21px ;font-weight: 700 ;text-transform: none ;">Library Services</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>Our Library is stocked with collections of periodicals, publication, books and journals.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-15">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-top gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 30px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-media-image" style="margin-bottom: 31px;"><img src="upload/col-icon-2.png" alt="" width="43" height="45" title="col-icon-2" /></div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 21px ;font-weight: 700 ;text-transform: none ;">International Scholarship</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>There are opportunities of getting local/foreign scholarships in Tansian University.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-15">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-top gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 30px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-media-image" style="margin-bottom: 33px;"><img src="upload/col-icon-3.png" alt="" width="40" height="43" title="col-icon-3" /></div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 21px ;font-weight: 700 ;text-transform: none ;">Academics</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>All our courses are approved and accredited by the National Universities Commission (NUC).</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-15">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-top gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 30px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-media-image" style="margin-bottom: 29px;"><img src="upload/col-icon-4.png" alt="" width="47" height="47" title="col-icon-4" /></div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 21px ;font-weight: 700 ;text-transform: none ;">Campus Life</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>We have zero tolerance for cult activities, sexual harassment and all sorts of exam malpractices.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding: 660px 0px 30px 0px;">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div class="gdlr-core-pbf-background" style="background-image: url(upload/bigger_view.jpg) ;background-size: cover ;background-position: center ;background-attachment: fixed ;"></div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container"></div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding: 90px 0px 30px 0px;">
                        <div class="gdlr-core-pbf-background-wrap"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 45px ;">
                                        <div class="gdlr-core-title-item-title-wrap clearfix">
                                            <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 27px ;font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;">The Application Process</h3></div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20 gdlr-core-column-first" data-skin="Blut Title Column Service">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-left gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 20px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-character" style="margin-top: 5px;margin-right: 33px;margin-left: 7px;font-size: 45px ;color: #3db166 ;">1</div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 18px ;text-transform: none ;">Select Course</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>View all our courses and select the course of your choice</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20" data-skin="Blut Title Column Service">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-left gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 20px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-character" style="margin-top: 5px;margin-right: 28px;margin-left: 3px;font-size: 45px ;color: #3db166 ;">2</div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 18px ;text-transform: none ;">Apply</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>Make the admission payment and proceed with application. You will a received confirmation message after submission</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20" data-skin="Blut Title Column Service">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-left gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 20px;">
                                                    <div class="gdlr-core-column-service-media gdlr-core-character" style="margin-top: 5px;font-size: 45px ;color: #3db166 ;">3</div>
                                                    <div class="gdlr-core-column-service-content-wrapper">
                                                        <div class="gdlr-core-column-service-title-wrap">
                                                            <h3 class="gdlr-core-column-service-title gdlr-core-skin-title" style="font-size: 18px ;text-transform: none ;">Registration</h3></div>
                                                        <div class="gdlr-core-column-service-content" style="font-size: 16px ;text-transform: none ;">
                                                            <p>Visit the Registrar's office with your credentials to complete your registration</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20 gdlr-core-column-first" data-skin="Blut Title Column Service">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                              <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-left gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 20px;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20" data-skin="Blut Title Column Service">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                              <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-left gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 20px;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-20" data-skin="Blut Title Column Service">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                              <div class="gdlr-core-column-service-item gdlr-core-item-pdb  gdlr-core-left-align gdlr-core-column-service-icon-left gdlr-core-no-caption gdlr-core-item-pdlr" style="padding-bottom: 20px;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-section">
                        <div class="gdlr-core-pbf-section-container gdlr-core-container clearfix">
                            <div class="gdlr-core-pbf-element">
                                <div class="gdlr-core-divider-item gdlr-core-divider-item-normal gdlr-core-item-pdlr gdlr-core-center-align" style="margin-bottom: 15px ;">
                                    <div class="gdlr-core-divider-line gdlr-core-skin-divider" style="border-color: #50bd77 ;border-bottom-width: 3px ;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding: 60px 0px 50px 0px;">
                      <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                          <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                              <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 40px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 22px ;font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;">Methods of Application</h3></div>
                                                </div>
                                            </div>
                                            
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-icon-list-item gdlr-core-item-pdlr gdlr-core-item-pdb clearfix " style="padding-bottom: 25px ;">
                                                    <ul>
                                                        <li class=" gdlr-core-skin-divider" style="margin-bottom: 22px ;"><span class="gdlr-core-icon-list-icon-wrap" style="margin-top: 5px ;"><i class="gdlr-core-icon-list-icon fa fa-dot-circle-o" style="color: #50bd77 ;font-size: 18px ;width: 18px ;" ></i></span>
                                                            <div class="gdlr-core-icon-list-content-wrap"><span class="gdlr-core-icon-list-content" style="font-size: 17px ;">Application Forms are obtainable on this website (<a href="#online-application"><strong>Online Application</strong></a>) and from the Admissions' Office, Tansian University, Umunya (Umunya/Oba Campuses), on payment of ₦10,000.00 (Ten Thousand Naira) only, into the Catholic Diocese of Ekwulobia - University Fund Bank Account No. 1211869000 at any branch of Zenith Bank Plc Nationwide (<a href="payment.php"><strong>Click Here to Pay Online</strong></a>).</p>
</span></div>
                                                        </li>
                                                        <li class=" gdlr-core-skin-divider" style="margin-bottom: 22px ;"><span class="gdlr-core-icon-list-icon-wrap" style="margin-top: 5px ;"><i class="gdlr-core-icon-list-icon fa fa-dot-circle-o" style="color: #50bd77 ;font-size: 18px ;width: 18px ;" ></i></span>
                                                            <div class="gdlr-core-icon-list-content-wrap"><span class="gdlr-core-icon-list-content" style="font-size: 17px ;"><strong>FORMS PURCHASED FROM THE SCHOOL:</strong> All Application Forms should be returned to the Registrar, Tansian University, Umunya, Anambra State. Presentation of Original Evidence of form payment is also required.</span></div>
                                                        </li>
                                                        <li class=" gdlr-core-skin-divider" style="margin-bottom: 22px ;"><span class="gdlr-core-icon-list-icon-wrap" style="margin-top: 5px ;"><i class="gdlr-core-icon-list-icon fa fa-dot-circle-o" style="color: #50bd77 ;font-size: 18px ;width: 18px ;" ></i></span>
                                                            <div class="gdlr-core-icon-list-content-wrap"><span class="gdlr-core-icon-list-content" style="font-size: 17px ;">Screening is on-going</span></div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 10px ;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 17px ;text-transform: none ;">
                                                        <p>Application Forms are also obtainable from the following centres below:</p>

<ol>
    <li>Konigin Des Friedens College, No 1, Queen of Peace Drive, Off No. 57A Awkunanaw Street Achara Layout, Enugu, Enugu State.</li>
    <li> Our Lady Waldenstein Educational Centre, No. 6 Pius O. Akam Avenue, Oka-Uga, Aguata L.G.A., Anambra State.</li>
</ol>

<p>For further information send us an email: <br><strong><a href="mailto:admissions@tansianuniversity.edu.ng">admissions@tansianuniversity.edu.ng</a></strong> <br>or call: <br><strong>08064131134 <br>08065197885 <br>08038408011<br>08032370760</strong></p>
                                                    </div>
                                                </div>
                                            </div>

                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 40px ;">
                                                    <div class="gdlr-core-title-item-title-wrap clearfix">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title " style="font-size: 22px ;font-weight: 700 ;letter-spacing: 0px ;text-transform: none ;"><a id="online-application">Online Application</a></h3></div>
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                            <!---Form Start --->
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-contact-form-7-item gdlr-core-item-pdlr gdlr-core-item-pdb ">
                                                    <div role="form" class="wpcf7" id="wpcf7-f5439-p5433-o1" lang="en-US" dir="ltr">
                                                        <div class="screen-reader-response"></div>
                                                        <form action="process.php" method="post" class="wpcf7-form" validate>
      
                                                            <p><span class="wpcf7-form-control-wrap your-name"><label>Name *</label><input type="text" name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name *" required /></span></p>
                                                            <p><span class="wpcf7-form-control-wrap your-name"><label>Phone *</label><input type="tel" name="phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Phone Number *" required /></span></p>
                                                            <p><span class="wpcf7-form-control-wrap your-email"><label>Email *</label><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email Address *" required /></span></p>
                                                            <p><span class="wpcf7-form-control-wrap your-name"><label>Date of Birth *</label><input type="text" name="dob" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="dd-mm-yyyy *" required /></span></p>
                                                            <p> <span class="wpcf7-form-control-wrap tour-time"><label>Gender *</label><select name="gender" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false"><option value="Select Gender*" required >--- Select Gender --- *</option><option value="Male">Male</option><option value="Female">Female</option></select></span></p>

                                                            <p><span class="wpcf7-form-control-wrap special-request"><label>Address *</label><textarea name="address" cols="40" rows="3" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Address *"required></textarea></span></p>
                                                            <p><span class="wpcf7-form-control-wrap your-name"><label>Payment Reference *</label><input type="text" name="reference" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Payment Reference Number *" required /></span></p>
                                                           <p> <span class="wpcf7-form-control-wrap tour-time"><label>Course *</label><select name="course" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false"><option value="Select Course*" required >--- Select Course --- *</option><option value="B.Sc Chemistry">B.Sc Chemistry</option>
    <option value="B.Sc Computer Science">B.Sc Computer Science</option>
    <option value="B.Sc Industrial Chemistry">B.Sc Industrial Chemistry</option>
    <option value="B.Sc Information and Communication Technology">B.Sc Information and Communication Technology</option>
    <option value="B.Sc Microbiology">B.Sc Microbiology</option>
    <option value="B.Sc Physics">B.Sc Physics</option>
    <option value="B.Sc Physics and Electronics">B.Sc Physics and Electronics</option>
    <option value="B.Sc Accounting">B.Sc Accounting</option>
    <option value="B.Sc Banking and Finance">B.Sc Banking and Finance</option>
    <option value="B.Sc Business Administration">B.Sc Business Administration</option>
    <option value="B.Sc Criminology and Security Studies">B.Sc Criminology and Security Studies</option>
    <option value="B.Sc Economics">B.Sc Economics</option>
    <option value="B.Sc Economics and Statistics">B.Sc Economics and Statistics</option>
    <option value="B.Sc International Relations">B.Sc International Relations</option>
    <option value="B.Sc Mass Communication">B.Sc Mass Communication</option>
    <option value="B.Sc Philosophy and Religious Studies">B.Sc Philosophy and Religious Studies</option>
    <option value="B.Sc Political Science">B.Sc Political Science</option>
    <option value="B.Sc Public Administration">B.Sc Public Administration</option>
    <option value="B.Sc Statistics">B.Sc Statistics</option>
    <option value="B.Ed Primary Education/Early Childhood">B.Ed Primary Education/Early Childhood</option>
    <option value="B.Ed Education Management">B.Ed Education Management</option>
    <option value="B.Ed Guidance and Counselling">B.Ed Guidance and Counselling</option>
    <option value="B.A (Ed) Education/English Language and Literary Studies">B.A (Ed) Education/English Language and Literary Studies</option>
    <option value="B.A (Ed) Education/CRS">B.A (Ed) Education/CRS</option>
    <option value="B.Sc (Ed) Education/Biology">B.Sc (Ed) Education/Biology</option>
    <option value="B.Sc (Ed) Education/Economics">B.Sc (Ed) Education/Economics</option>
    <option value="B.Sc (Ed) Education/Political Science">B.Sc (Ed) Education/Political Science</option>
    <option value="B.Sc (Ed) Education/Accounting<">B.Sc (Ed) Education/Accounting</option>
    <option value="B.Sc Architecture">B.Sc Architecture</option>
    <option value="B.Sc Estate Management">B.Sc Estate Management</option>
    <option value="B.Sc Urban and Regional Planning">B.Sc Urban and Regional Planning</option>
    <option value="B.NSc Nursing Science">B.NSc Nursing Science</option>
    <option value="B.MLS Medical Laboratory Science<">B.MLS Medical Laboratory Science</option>
    <option value="B.Sc Public Health">B.Sc Public Health</option>
    <option value="LL.B. Law">LL.B. Law</option>
                                                           
                                                           </select></span></p>
                                                            <p>
                                                                <input type="submit" value="Submit Now" class="wpcf7-form-control wpcf7-submit" name="submit"/>
                                                            </p>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!---Form end --->

                                        </div>
                                    </div>
                                </div>
                        </div>
                      </div>
                  </div>
                </div>
            </div>

            <footer>
                <div class="kingster-footer-wrapper ">
                    <div class="kingster-footer-container kingster-container clearfix">
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="text-2" class="widget widget_text kingster-widget">
                                <div class="textwidget">
                                    <p><img src="upload/footer-logo.png" alt="" />
                                        <br /> <span class="gdlr-core-space-shortcode" id="span_1dd7_10"></span>
                                        <br /> P.M.B 0006,
                                        <br /> Along Enugu - Onitsha Expressway,
                                        <br /> Umunya, 
                                        <br />Anambra State, Nigeria</p>
                                    <p><span id="span_1dd7_11"><a id="a_1dd7_8" href="tel:+2348039310930">+234 (0) 803 931 0930</a></span>
                                        <br /> <span class="gdlr-core-space-shortcode" id="span_1dd7_12"></span>
                                        <br /> <a id="a_1dd7_8" href="mailto:enquiry@tansianuniversity.edu.ng">enquiry@tansianuniversity.edu.ng</a></p>
                                    <div class="gdlr-core-divider-item gdlr-core-divider-item-normal gdlr-core-left-align">
                                        <div class="gdlr-core-divider-line gdlr-core-skin-divider" id="div_1dd7_111"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-2" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">The Team</h3><span class="clear"></span>
                                <div class="menu-our-campus-container">
                                    <ul id="menu-our-campus" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="chancellor.php">The Chancellor</a></li>
                                        <li class="menu-item"><a href="pro-chancellor.php">The Pro-Chancellor</a></li>
                                        <li class="menu-item"><a href="vice-chancellor.php">The Vice Chancellor</a></li>
                                        <li class="menu-item"><a href="deputy-vice-chancellor.php">The Deputy Vice Chancellor</a></li>
                                        <li class="menu-item"><a href="registrar.php">The Registrar</a></li>
                                        <li class="menu-item"><a href="bursar.php">The Bursar</a></li>
										<li class="menu-item"><a href="founder.php"><strong>THE FOUNDER</strong></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-3" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">Quick Links</h3><span class="clear"></span>
                                <div class="menu-campus-life-container">
                                    <ul id="menu-campus-life" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-plain">
                                        <li class="menu-item"><a href="calendar.php">Tansian University Year Calendar</a></li>
                                        <li class="menu-item"><a href="radio.php">Tansian University Radio</a></li>
                                        <li class="menu-item"><a href="films.php">Tansian University Films</a></li>
                                        <li class="menu-item"><a href="sports.php">Tansian University Sports Academy</a></li>
                                        <li class="menu-item"><a href="health-clinic.php">Tansian University Health Clinic</a></li>
                                        <li class="menu-item"><a href="alumni.php">Tansian University Alumni</a></li>
                                        <li class="menu-item"><a href="https://webmail.tansianuniversity.edu.ng/" target="_blank">Staff Mail</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="kingster-footer-column kingster-item-pdlr kingster-column-15">
                            <div id="gdlr-core-custom-menu-widget-4" class="widget widget_gdlr-core-custom-menu-widget kingster-widget">
                                <h3 class="kingster-widget-title">University Anthem (Lyrics)</h3><span class="clear"></span>
                                <div style="overflow: auto; height:235px">
                                    <p><em>Tansian University (2x)</em></p>

                                    <p><em>Home of active learning and high quality education</em></p>
                                    
                                    <p><em>Knowledge is power, knowledge is virtue<br />
                                    Scientia Potestas et Virtus (2x)</em></p>

                                    <p><em>Tansian University (2x)</em></p>

                                    <p><em>A citadel of learning to immortalize Blessed Iwene Tansian<br />
                                    A citadel of good living for all peoples without distinction<br />
                                    A citadel where Christ is the centre for ages and ages to come<br />
                                    So may we pray God to lead us on<br />
                                    In this life and in the life to come</em></p>
                                    <p><em>Iwene</em></p>

                                    <p><em>Tansian University (2x)</em></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="kingster-copyright-wrapper">
                    <div class="kingster-copyright-container kingster-container clearfix">
                        <div class="kingster-copyright-left kingster-item-pdlr">Copyright &copy; 2022, Tansian University</a>. All Rights Reserved. | <small>Website by <a href="http://www.codecmultimedia.com/" target="_blank" title="CODEC Multimedia Services">CODEC Multimedia Services</a></small></div>
                        <div class="kingster-copyright-right kingster-item-pdlr">
                            <div class="gdlr-core-social-network-item gdlr-core-item-pdb  gdlr-core-none-align" id="div_1dd7_112">
                                <a href="https://www.facebook.com/tansianuniversityumunya/" target="_blank" class="gdlr-core-social-network-icon" title="facebook">
                                    <i class="fa fa-facebook" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="google-plus">
                                    <i class="fa fa-google-plus" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="linkedin">
                                    <i class="fa fa-linkedin" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="skype">
                                    <i class="fa fa-skype" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="twitter">
                                    <i class="fa fa-twitter" ></i>
                                </a>
                                <a href="#" class="gdlr-core-social-network-icon" title="instagram">
                                    <i class="fa fa-instagram" ></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

        </div>
    </div>


	<script type='text/javascript' src='js/jquery/jquery.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='plugins/goodlayers-core/plugins/combine/script.js'></script>
    <script type='text/javascript'>
        var gdlr_core_pbf = {
            "admin": "",
            "video": {
                "width": "640",
                "height": "360"
            },
            "ajax_url": "#"
        };
    </script>
    <script type='text/javascript' src='plugins/goodlayers-core/include/js/page-builder.js'></script>
    <script type='text/javascript' src='js/jquery/ui/effect.min.js'></script>
    <script type='text/javascript'>
        var kingster_script_core = {
            "home_url": "index.php"
        };
    </script>
    <script type='text/javascript' src='js/plugins.min.js'></script>
</body>
</html>